"""Integrations and shared services."""
